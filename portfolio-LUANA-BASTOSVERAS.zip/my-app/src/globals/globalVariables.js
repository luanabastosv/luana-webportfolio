export const appTitle = 'Luana\'s Portfolio';
export const appAuthor = 'Luana Bastos';